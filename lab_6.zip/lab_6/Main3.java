

class Main3{

    public static void main(String args []){

   Car C = new Car("Honda", 70, 4);

   C.showDetails();

   System.out.println();

   Bike B = new Bike("Hayabusa", 60, "Covered");

B.showDetails();

        
    }
    
}