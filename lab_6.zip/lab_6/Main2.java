  

   class Main2{
  
       public static void main(String args []){

    GraduateStudent G= new GraduateStudent("Ahad",21,"ARI88","AI");
    
       G.displayInfo();
           
       }
   }