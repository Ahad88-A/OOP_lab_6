   


    class Car extends Vehicle{
   
        int numDoors;
        
       Car(String brand , double speed , int numDoors){
   
        super(brand, speed);
   
        this.numDoors=numDoors;
       }
   
       public void showDetails(){
   
        super.showDetails();
   
        System.out.println("Number of doors :"+numDoors);
       }
    }