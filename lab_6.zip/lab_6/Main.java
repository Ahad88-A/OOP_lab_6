   

    class Main{
   
        public static void main(String args []){
   
        Dog sound = new Dog(" love", 4);
   
        sound.displayInfo();
   
        System.out.println();
   
        sound.makeSound();
            
        }
    }